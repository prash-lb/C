#ifndef __LEVENSHTEIN__
#define __LEVENSHTEIN__

    int DistanceDeLevenshtein(char * chaine1, char * chaine2 );


#endif